package nl.tudelft.datagathererapp

import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileWriter
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var ipEditText: EditText
    private lateinit var sendPacketsButton: Button
    private lateinit var downloadButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ipEditText = findViewById(R.id.ipEditText)
        sendPacketsButton = findViewById(R.id.sendPacketsButton)
        downloadButton = findViewById(R.id.downloadButton)

        sendPacketsButton.setOnClickListener {
            sendPackets()
        }

        downloadButton.setOnClickListener {
            downloadCsv()
        }
    }

    private fun sendPackets() {
        // Implement UDP packet sending logic here
        // Extract IP address from ipEditText.text.toString()

        // Generate random source and destination ports
        val sourcePort = Random().nextInt(65535) + 1
        val destinationPort = Random().nextInt(65535) + 1

        // Get the numeric ID (replace this with your own logic)
        val numericId = System.currentTimeMillis()

        // Save data to CSV file
        saveToCsv(numericId, sourcePort, destinationPort)

        // Implement UDP packet sending logic using the extracted IP address,
        // sourcePort, destinationPort, and numericId
    }

    private fun saveToCsv(numericId: Long, sourcePort: Int, destinationPort: Int) {
        try {
            val csvFile = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "port_data.csv")
            val fileWriter = FileWriter(csvFile, true)

            // Append data to CSV file
            fileWriter.append("$numericId,$sourcePort,$destinationPort\n")

            fileWriter.flush()
            fileWriter.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun downloadCsv() {
        // Implement logic to download the CSV file from the specified location
        // For simplicity, you can use an Intent to open a file picker
        // and let the user choose a location to save the file
    }
}
